# V-SGC Route Optimizer — Setup Guide
## ME4098D: Last-Mile Delivery Optimization

---

## What This Is
A full-stack route optimization system implementing your exact V-SGC methodology:

```
Phase 1 (Clustering):
  Step 1 → Load customer data
  Step 2 → K-Means++ seeding (find candidate exemplars)
  Step 3 → V-SGC MILP Re-Clustering (scipy.optimize.milp / HiGHS solver)
  Step 4 → Assign clusters to nearest depot

Phase 2 (Routing):
  Step 5 → TSPTW MILP routing per cluster (Big-M constraints)
         → 2-opt Nearest-Neighbour fallback for large clusters
```

---

## Installation

### Step 1: Install Python dependencies
```bash
pip install flask numpy scipy
```

### Step 2: (Optional) Install Gurobi for faster solving
```bash
pip install gurobipy
# Requires a Gurobi license — free academic license at gurobi.com
# The app works WITHOUT Gurobi using scipy's built-in HiGHS solver
```

---

## Running the Server

```bash
cd backend/
python app.py
```

Server starts at: **http://localhost:5050**

Then open **static/index.html** in your browser (or visit http://localhost:5050).

---

## API Reference

### POST /api/solve
Runs the full V-SGC pipeline on your data.

**Request body:**
```json
{
  "customers": [
    {"x": 35.2, "y": 48.7, "demand": 15, "label": "Shop A",
     "time_earliest": 60, "time_latest": 300}
  ],
  "depots": [
    {"x": 50, "y": 50, "name": "Main Depot"}
  ],
  "num_vehicles": 3,
  "vehicle_capacity": 100,
  "speed_kmh": 30,
  "milp_time_limit": 30
}
```

**Response:**
```json
{
  "status": "optimal",
  "routes": [
    {
      "vehicle": 1,
      "depot_idx": 0,
      "stops": [2, 0, 4],
      "demand": 42,
      "distance": 28.3,
      "utilization": 42.0
    }
  ],
  "summary": {
    "total_distance": 84.5,
    "num_routes": 3,
    "solve_time_s": 2.4,
    "algorithm": "V-SGC (K-Means + MILP Grafting + TSPTW)"
  },
  "log": ["K-Means: 9 candidates in 0.01s", "V-SGC MILP: 3 clusters in 1.2s", ...]
}
```

### GET /api/health
Returns solver status.

---

## Coordinate System
- X and Y are in range **0–100** (abstract units)
- For real lat/lon data: pass coordinates directly, the Haversine formula is available in the backend

---

## Switching to Gurobi
In `app.py`, the `vsgc_milp_cluster()` and `tsptw_milp()` functions use `scipy.optimize.milp`.
To use Gurobi instead, replace with `gurobipy` model calls — the formulations are identical.

---

## Team
- Prarabdha Chatterjee (B220474PE)
- Aditya Jha (B220073PE)  
- Richard Binoy (B220058ME)

Guide: Dr. Pradeepmon T.G.
